/*
* Copyright (C) 2020  钟先耀
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/
/*    $OpenBSD: if_iwm.c,v 1.316 2020/12/07 20:09:24 tobhe Exp $    */

/*
 * Copyright (c) 2014, 2016 genua gmbh <info@genua.de>
 *   Author: Stefan Sperling <stsp@openbsd.org>
 * Copyright (c) 2014 Fixup Software Ltd.
 * Copyright (c) 2017 Stefan Sperling <stsp@openbsd.org>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/*-
 * Based on BSD-licensed source modules in the Linux iwlwifi driver,
 * which were used as the reference documentation for this implementation.
 *
 ***********************************************************************
 *
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 * redistributing this file, you may do so under either license.
 *
 * GPL LICENSE SUMMARY
 *
 * Copyright(c) 2007 - 2013 Intel Corporation. All rights reserved.
 * Copyright(c) 2013 - 2015 Intel Mobile Communications GmbH
 * Copyright(c) 2016 Intel Deutschland GmbH
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110,
 * USA
 *
 * The full GNU General Public License is included in this distribution
 * in the file called COPYING.
 *
 * Contact Information:
 *  Intel Linux Wireless <ilw@linux.intel.com>
 * Intel Corporation, 5200 N.E. Elam Young Parkway, Hillsboro, OR 97124-6497
 *
 *
 * BSD LICENSE
 *
 * Copyright(c) 2005 - 2013 Intel Corporation. All rights reserved.
 * Copyright(c) 2013 - 2015 Intel Mobile Communications GmbH
 * Copyright(c) 2016 Intel Deutschland GmbH
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  * Neither the name Intel Corporation nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*-
 * Copyright (c) 2007-2010 Damien Bergamini <damien.bergamini@free.fr>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "ItlIwm.hpp"

void ItlIwm::
iwm_phy_ctxt_cmd_hdr(struct iwm_softc *sc, struct iwm_phy_ctxt *ctxt,
    struct iwm_phy_context_cmd *cmd, uint32_t action, uint32_t apply_time)
{
    memset(cmd, 0, sizeof(struct iwm_phy_context_cmd));

    cmd->id_and_color = htole32(IWM_FW_CMD_ID_AND_COLOR(ctxt->id,
        ctxt->color));
    cmd->action = htole32(action);
    cmd->apply_time = htole32(apply_time);
}

static uint8_t
iwm_get_channel_width(struct ieee80211com *ic, struct ieee80211_channel *c)
{
    uint8_t ret = IWM_PHY_VHT_CHANNEL_MODE20;
    if (ic->ic_bss == NULL || ic->ic_state < IEEE80211_S_ASSOC) {
        return ret;
    }
    switch (ic->ic_bss->ni_chw) {
        case IEEE80211_CHAN_WIDTH_20_NOHT:
        case IEEE80211_CHAN_WIDTH_20:
            return IWM_PHY_VHT_CHANNEL_MODE20;
        case IEEE80211_CHAN_WIDTH_40:
            return IWM_PHY_VHT_CHANNEL_MODE40;
        case IEEE80211_CHAN_WIDTH_80:
            return IWM_PHY_VHT_CHANNEL_MODE80;
        case IEEE80211_CHAN_WIDTH_160:
            return IWM_PHY_VHT_CHANNEL_MODE160;
        default:
            XYLog("Invalid channel width=%u\n", ic->ic_bss->ni_chw);
            return ret;
    }
}

static uint8_t
iwm_get_ctrl_pos(struct ieee80211com *ic, struct ieee80211_channel *c)
{
    if (ic->ic_bss == NULL || ic->ic_state < IEEE80211_S_ASSOC || iwm_get_channel_width(ic, c) == IWM_PHY_VHT_CHANNEL_MODE20)
        return IWM_PHY_VHT_CTRL_POS_1_BELOW;
    
    signed int offset = ic->ic_bss->ni_chan->ic_freq - ic->ic_bss->ni_chan->ic_center_freq1;
    switch (offset) {
        case -70:
            return IWM_PHY_VHT_CTRL_POS_4_BELOW;
        case -50:
            return IWM_PHY_VHT_CTRL_POS_3_BELOW;
        case -30:
            return IWM_PHY_VHT_CTRL_POS_2_BELOW;
        case -10:
            return IWM_PHY_VHT_CTRL_POS_1_BELOW;
        case  10:
            return IWM_PHY_VHT_CTRL_POS_1_ABOVE;
        case  30:
            return IWM_PHY_VHT_CTRL_POS_2_ABOVE;
        case  50:
            return IWM_PHY_VHT_CTRL_POS_3_ABOVE;
        case  70:
            return IWM_PHY_VHT_CTRL_POS_4_ABOVE;
        default:
            XYLog("Invalid channel definition freq=%d %d\n", ic->ic_bss->ni_chan->ic_freq, offset);
            /* fall through */
        case 0:
            /*
             * The FW is expected to check the control channel position only
             * when in HT/VHT and the channel width is not 20MHz. Return
             * this value as the default one.
             */
            return IWM_PHY_VHT_CTRL_POS_1_BELOW;
    }
}

void ItlIwm::
iwm_phy_ctxt_cmd_data(struct iwm_softc *sc, struct iwm_phy_context_cmd *cmd,
    struct ieee80211_channel *chan, uint8_t chains_static,
    uint8_t chains_dynamic)
{
    struct ieee80211com *ic = &sc->sc_ic;
    uint8_t active_cnt, idle_cnt;

    cmd->ci.band = IEEE80211_IS_CHAN_2GHZ(chan) ?
        IWM_PHY_BAND_24 : IWM_PHY_BAND_5;
    cmd->ci.channel = ieee80211_chan2ieee(ic, chan);
    cmd->ci.width = iwm_get_channel_width(ic, chan);
    cmd->ci.ctrl_pos = iwm_get_ctrl_pos(ic, chan);

    /* Set rx the chains */
    idle_cnt = chains_static;
    active_cnt = chains_dynamic;

    cmd->rxchain_info = htole32(iwm_fw_valid_rx_ant(sc) <<
                    IWM_PHY_RX_CHAIN_VALID_POS);
    cmd->rxchain_info |= htole32(idle_cnt << IWM_PHY_RX_CHAIN_CNT_POS);
    cmd->rxchain_info |= htole32(active_cnt <<
        IWM_PHY_RX_CHAIN_MIMO_CNT_POS);

    cmd->txchain_info = htole32(iwm_fw_valid_tx_ant(sc));
}

int ItlIwm::
iwm_phy_ctxt_cmd_uhb(struct iwm_softc *sc, struct iwm_phy_ctxt *ctxt,
                     uint8_t chains_static, uint8_t chains_dynamic, uint32_t action,
                     uint32_t apply_time)
{
    XYLog("%s\n", __FUNCTION__);
    struct ieee80211com *ic = &sc->sc_ic;
    struct iwm_phy_context_cmd_uhb cmd;
    uint8_t active_cnt, idle_cnt;
    struct ieee80211_channel *chan = ctxt->channel;
    
    memset(&cmd, 0, sizeof(cmd));
    cmd.id_and_color = htole32(IWM_FW_CMD_ID_AND_COLOR(ctxt->id,
                                                       ctxt->color));
    cmd.action = htole32(action);
    cmd.apply_time = htole32(apply_time);
    
    cmd.ci.band = IEEE80211_IS_CHAN_2GHZ(chan) ?
    IWM_PHY_BAND_24 : IWM_PHY_BAND_5;
    cmd.ci.channel = htole32(ieee80211_chan2ieee(ic, chan));
    cmd.ci.width = iwm_get_channel_width(ic, chan);
    cmd.ci.ctrl_pos = iwm_get_ctrl_pos(ic, chan);
    
    idle_cnt = chains_static;
    active_cnt = chains_dynamic;
    cmd.rxchain_info = htole32(iwm_fw_valid_rx_ant(sc) <<
                               IWM_PHY_RX_CHAIN_VALID_POS);
    cmd.rxchain_info |= htole32(idle_cnt << IWM_PHY_RX_CHAIN_CNT_POS);
    cmd.rxchain_info |= htole32(active_cnt <<
                                IWM_PHY_RX_CHAIN_MIMO_CNT_POS);
    cmd.txchain_info = htole32(iwm_fw_valid_tx_ant(sc));
    
    return iwm_send_cmd_pdu(sc, IWM_PHY_CONTEXT_CMD, 0, sizeof(cmd), &cmd);
}

int ItlIwm::
iwm_phy_ctxt_cmd(struct iwm_softc *sc, struct iwm_phy_ctxt *ctxt,
    uint8_t chains_static, uint8_t chains_dynamic, uint32_t action,
    uint32_t apply_time)
{
    XYLog("%s\n", __FUNCTION__);
    struct iwm_phy_context_cmd cmd;
    
    /*
     * Intel increased the size of the fw_channel_info struct and neglected
     * to bump the phy_context_cmd struct, which contains an fw_channel_info
     * member in the middle.
     * To keep things simple we use a separate function to handle the larger
     * variant of the phy context command.
     */
    if (isset(sc->sc_enabled_capa, IWM_UCODE_TLV_CAPA_ULTRA_HB_CHANNELS))
        return iwm_phy_ctxt_cmd_uhb(sc, ctxt, chains_static,
                                    chains_dynamic, action, apply_time);

    iwm_phy_ctxt_cmd_hdr(sc, ctxt, &cmd, action, apply_time);

    iwm_phy_ctxt_cmd_data(sc, &cmd, ctxt->channel,
        chains_static, chains_dynamic);

    return iwm_send_cmd_pdu(sc, IWM_PHY_CONTEXT_CMD, 0,
        sizeof(struct iwm_phy_context_cmd), &cmd);
}
